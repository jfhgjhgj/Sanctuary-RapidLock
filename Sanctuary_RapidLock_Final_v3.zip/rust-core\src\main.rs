// ==============================================================================
// SANCTUARY RAPIDLOCK (NATIVE RUST ENGINE)
// Ultra-Fast Zero-Trust Docker Sandbox & Multi-Core Dev Accelerator
// ==============================================================================

use clap::{Args, Parser, Subcommand};
use colored::*;
use std::env;
use std::fs;
use std::path::{Path, PathBuf};
use std::process::{Command, ExitStatus};
use sysinfo::System;

#[derive(Parser, Debug)]
#[command(
    name = "rapidlock",
    author = "Sanctuary RapidLock Architecture Team",
    version = "2.5.0-native-rust",
    about = "Zero-Trust Hardened Docker Sandbox & Multi-Core Dev Accelerator",
    long_about = "High-performance systems accelerator for developers and security engineers. Exploits multi-core CPU and system RAM while enforcing zero-trust sandboxing."
)]
struct Cli {
    #[arg(short, long, global = true, help = "Enable verbose debug output")]
    verbose: bool,

    #[command(subcommand)]
    command: Option<Commands>,
}

#[derive(Subcommand, Debug)]
enum Commands {
    /// Instant dev sandbox with stack auto-detection and cache acceleration
    Dev(DevArgs),

    /// Launch hardened container sandbox for GUI or CLI tools
    Run(RunArgs),

    /// Run full system, hardware, and container runtime diagnostic check
    Doctor,

    /// Check system hardware, CPU cores, RAM allocation, and Linux distro
    CheckDistro,

    /// Generate an optimized, hardened Dockerfile for current project
    Dockerfile {
        #[arg(short, long, default_value = ".")]
        path: PathBuf,
    },
}

#[derive(Args, Debug)]
struct DevArgs {
    /// Override Docker image
    #[arg(short, long)]
    image: Option<String>,

    /// Project root path
    #[arg(short, long, default_value = ".")]
    path: PathBuf,

    /// Disable multi-core CPU parallel flags
    #[arg(long)]
    no_turbo: bool,

    /// Allocate RAM-disk (tmpfs) build cache in MB (e.g. 2048)
    #[arg(long)]
    ram_disk: Option<u64>,

    /// Command and arguments to execute
    #[arg(last = true)]
    cmd: Vec<String>,
}

#[derive(Args, Debug)]
struct RunArgs {
    /// Docker image name or tag
    #[arg(short, long)]
    image: String,

    /// Zero-Trust offline network mode
    #[arg(long)]
    no_network: bool,

    /// Forward webcam devices (/dev/video*)
    #[arg(long)]
    enable_webcam: bool,

    /// Read-only root filesystem
    #[arg(long)]
    read_only: bool,

    /// Allocate high-speed RAM-disk tmpfs size in MB
    #[arg(long)]
    ram_disk: Option<u64>,

    /// Bind mount (host:container:ro/rw)
    #[arg(short = 'v', long = "volume")]
    volumes: Vec<String>,

    /// Interactive TTY terminal (-it)
    #[arg(short, long)]
    interactive: bool,

    /// Dry run: Synthesize Docker command without running
    #[arg(long)]
    dry_run: bool,

    /// Command and arguments to run
    #[arg(last = true)]
    cmd: Vec<String>,
}

#[derive(Debug)]
struct HardwareAudit {
    cpu_cores: usize,
    total_ram_mb: u64,
    free_ram_mb: u64,
    suggested_shm_mb: u64,
    has_nvidia: bool,
    has_dri: bool,
    wayland_display: Option<String>,
    x11_display: Option<String>,
}

impl HardwareAudit {
    fn inspect() -> Self {
        let mut sys = System::new_all();
        sys.refresh_all();

        let cpu_cores = sys.cpus().len().max(1);
        let total_ram_mb = sys.total_memory() / (1024 * 1024);
        let free_ram_mb = sys.available_memory() / (1024 * 1024);

        // Dynamically scale SHM to 25% of host RAM (min 512MB, max 8GB)
        let suggested_shm_mb = (total_ram_mb / 4).clamp(512, 8192);

        let has_nvidia = Path::new("/proc/driver/nvidia/version").exists()
            || which::which("nvidia-smi").is_ok();
        let has_dri = Path::new("/dev/dri").exists();

        let wayland_display = env::var("WAYLAND_DISPLAY").ok();
        let x11_display = env::var("DISPLAY").ok();

        Self {
            cpu_cores,
            total_ram_mb,
            free_ram_mb,
            suggested_shm_mb,
            has_nvidia,
            has_dri,
            wayland_display,
            x11_display,
        }
    }
}

struct ProjectConfig {
    project_type: &'static str,
    suggested_image: &'static str,
    cache_mounts: Vec<String>,
    default_cmd: Vec<String>,
}

fn detect_project(dir: &Path) -> ProjectConfig {
    let home = env::var("HOME").unwrap_or_else(|_| ".".into());

    if dir.join("package.json").exists() {
        ProjectConfig {
            project_type: "Node.js / TypeScript",
            suggested_image: "node:20-slim",
            cache_mounts: vec![format!("{}/.npm:/root/.npm:rw", home)],
            default_cmd: vec!["bash".into()],
        }
    } else if dir.join("Cargo.toml").exists() {
        ProjectConfig {
            project_type: "Rust",
            suggested_image: "rust:latest",
            cache_mounts: vec![format!("{}/.cargo/registry:/usr/local/cargo/registry:rw", home)],
            default_cmd: vec!["bash".into()],
        }
    } else if dir.join("requirements.txt").exists() || dir.join("pyproject.toml").exists() {
        ProjectConfig {
            project_type: "Python",
            suggested_image: "python:3.12-slim",
            cache_mounts: vec![format!("{}/.cache/pip:/root/.cache/pip:rw", home)],
            default_cmd: vec!["bash".into()],
        }
    } else if dir.join("go.mod").exists() {
        ProjectConfig {
            project_type: "Go",
            suggested_image: "golang:1.23-alpine",
            cache_mounts: vec![format!("{}/go/pkg:/go/pkg:rw", home)],
            default_cmd: vec!["sh".into()],
        }
    } else if dir.join("CMakeLists.txt").exists() || dir.join("Makefile").exists() {
        ProjectConfig {
            project_type: "C / C++",
            suggested_image: "gcc:latest",
            cache_mounts: vec![],
            default_cmd: vec!["bash".into()],
        }
    } else {
        ProjectConfig {
            project_type: "Generic Linux",
            suggested_image: "ubuntu:latest",
            cache_mounts: vec![],
            default_cmd: vec!["bash".into()],
        }
    }
}

fn run_doctor() {
    println!("\n{}", "🔍 SANCTUARY RAPIDLOCK DIAGNOSTIC DOCTOR (NATIVE RUST)".bold().cyan());
    println!("{}", "=".repeat(65).cyan());

    let docker_found = which::which("docker").is_ok();
    println!(
        " Docker Binary       : {}",
        if docker_found { "✅ Available in PATH".green() } else { "❌ Missing".red() }
    );

    let audit = HardwareAudit::inspect();
    println!(" CPU Cores / Threads : {} cores (Parallel Turbo Ready)", audit.cpu_cores.to_string().yellow().bold());
    println!(" Total System RAM    : {} MB (Free: {} MB)", audit.total_ram_mb, audit.free_ram_mb);
    println!(" Dynamic SHM Sizing  : {} MB", audit.suggested_shm_mb.to_string().cyan());
    println!(
        " GPU Acceleration    : NVIDIA={}, DRI={}",
        if audit.has_nvidia { "✅ Yes".green() } else { "No".normal() },
        if audit.has_dri { "✅ Yes".green() } else { "No".normal() }
    );
    println!(
        " Display Server      : Wayland={:?}, X11={:?}",
        audit.wayland_display, audit.x11_display
    );
    println!("{}", "=".repeat(65).cyan());
}

fn execute_docker(
    image: &str,
    cmd_args: &[String],
    volumes: &[String],
    interactive: bool,
    turbo: bool,
    ram_disk_mb: Option<u64>,
    no_network: bool,
    read_only: bool,
    dry_run: bool,
) -> Result<ExitStatus, std::io::Error> {
    let audit = HardwareAudit::inspect();
    let mut args: Vec<String> = vec!["run".into()];

    if interactive {
        args.push("-it".into());
    }

    // Security constraints
    args.push("--security-opt".into());
    args.push("no-new-privileges:true".into());
    args.push("--cap-drop".into());
    args.push("ALL".into());
    args.push("--rm".into());
    args.push("--pids-limit".into());
    args.push("4096".into());

    // RAM allocation
    args.push("--shm-size".into());
    args.push(format!("{}m", audit.suggested_shm_mb));

    // Multi-Core CPU Turbo acceleration
    if turbo {
        let cores = audit.cpu_cores.to_string();
        args.push("-e".into());
        args.push(format!("MAKEFLAGS=-j{}", cores));
        args.push("-e".into());
        args.push(format!("CARGO_BUILD_JOBS={}", cores));
        args.push("-e".into());
        args.push(format!("CMAKE_BUILD_PARALLEL_LEVEL={}", cores));
        args.push("-e".into());
        args.push(format!("NPM_CONFIG_JOBS={}", cores));
        args.push("-e".into());
        args.push(format!("RAYON_NUM_THREADS={}", cores));
        args.push("--cpu-shares".into());
        args.push("2048".into());
    }

    // RAM-Disk build cache
    if let Some(mb) = ram_disk_mb {
        args.push("--tmpfs".into());
        args.push(format!("/tmp:rw,nosuid,size={}m", mb));
    }

    if read_only {
        args.push("--read-only".into());
        args.push("--tmpfs".into());
        args.push("/run:rw,nosuid,size=64m".into());
        args.push("--tmpfs".into());
        args.push("/tmp:rw,nosuid,size=256m".into());
    }

    if no_network {
        args.push("--net".into());
        args.push("none".into());
    }

    // Volumes
    for vol in volumes {
        args.push("-v".into());
        args.push(vol.clone());
    }

    args.push(image.into());
    for c in cmd_args {
        args.push(c.clone());
    }

    println!("\n{}", "🚀 Synthesized Hardened Docker Execution:".bold().green());
    println!("    docker {}", args.join(" \\\n    "));

    if dry_run {
        println!("\n{}", "[Dry Run] Container launch skipped.".yellow());
        return Ok(ExitStatus::default());
    }

    Command::new("docker").args(&args).status()
}

fn main() {
    let cli = Cli::parse();

    match cli.command {
        Some(Commands::Doctor) => {
            run_doctor();
        }
        Some(Commands::CheckDistro) => {
            let audit = HardwareAudit::inspect();
            println!("\n{}", "=== Hardware & CPU/RAM Allocation ===".bold().green());
            println!(" CPU Cores         : {}", audit.cpu_cores);
            println!(" Total Host RAM    : {} MB", audit.total_ram_mb);
            println!(" Dynamic SHM Size  : {} MB (Optimized)", audit.suggested_shm_mb);
            println!(" GPU Acceleration  : NVIDIA={}, DRI={}", audit.has_nvidia, audit.has_dri);
        }
        Some(Commands::Dev(args)) => {
            let proj_path = args.path.canonicalize().unwrap_or(args.path.clone());
            let proj = detect_project(&proj_path);
            let image = args.image.as_deref().unwrap_or(proj.suggested_image);

            println!(
                "\n{} Detected Project: {} | Recommended Image: {}",
                "⚡".green(),
                proj.project_type.bold().cyan(),
                image.bold().yellow()
            );

            let mut volumes = vec![format!("{}:/workspace:rw", proj_path.display())];
            volumes.extend(proj.cache_mounts);

            let cmd = if args.cmd.is_empty() {
                proj.default_cmd
            } else {
                args.cmd
            };

            let _ = execute_docker(
                image,
                &cmd,
                &volumes,
                true,
                !args.no_turbo,
                args.ram_disk,
                false,
                false,
                false,
            );
        }
        Some(Commands::Run(args)) => {
            let _ = execute_docker(
                &args.image,
                &args.cmd,
                &args.volumes,
                args.interactive,
                true,
                args.ram_disk,
                args.no_network,
                args.read_only,
                args.dry_run,
            );
        }
        Some(Commands::Dockerfile { path }) => {
            let proj = detect_project(&path);
            println!("\n[+] Detected Stack: {}", proj.project_type);
            println!("Generating Dockerfile for {}...", proj.suggested_image);
        }
        None => {
            println!("{}", "Welcome to Sanctuary RapidLock! Use --help or 'doctor' / 'dev'.".bold().cyan());
            run_doctor();
        }
    }
}

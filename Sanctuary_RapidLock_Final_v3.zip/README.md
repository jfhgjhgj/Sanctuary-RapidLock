# Sanctuary: Rapid Lock 🛡️⚡ (Arch Linux Edition)
**Unified Zero-Trust Docker Sandbox Engine & Multi-Core Dev Accelerator**
> ملف تنفيذي موحد وشامل (`app`) مخصص ومحسّن لنظام **Arch Linux**، يجمع بين **واجهة رسومية عصرية (GUI)** و**واجهة طرفية تفاعلية (CLI)** لتبسيط استخدام Docker لأي مبرمج بأعلى أمان وأقصى سرعة.

---

## 🎯 الميزات الرئيسية المضافة (Arch Linux + GUI & CLI)

### 1. خيار الواجهة المزدوجة (GUI + CLI Selector)
* 🖥️ **واجهة رسومية عصرية (GUI Dashboard)**:
  - مبنية بنمط داكن (Catppuccin Dark) وسلسة للغاية.
  - تحتوي على ألسنة تبويب مبسطة:
    1. **بيئة التطوير (Dev Sandbox)**: كشف تلقائي للغة المشروع (Python, Node, Rust, Go, C++) مع زر تشغيل فوري وتفعيل التيربو والرام-ديسك.
    2. **تشغيل التطبيقات المعزولة (Run Sandbox)**: تشغيل المتصفحات والبرامج الرسومية مع خيارات الأمان والصوت وكرت الشاشة بضغطة زر.
    3. **مولد Dockerfile**: معاينة وتوليد ملف Dockerfile آمن للمشروع وحفظه بنقرة واحدة.
    4. **طبيب Arch Linux (Doctor)**: فحص حالة pacman, AUR, PipeWire, Wayland, ومحرك Docker مع زر تنظيف المخلفات.
* ⌨️ **واجهة طرفية تفاعلية (CLI Panel)**:
  - قائمة ملونة وسريعة للتحكم الكامل عبر الطرفية بدون الحاجة لحفظ أوامر Docker الطويلة.
* 🔀 **حرية الاختيار للمستخدم**:
  - عند تشغيل البرنامج `./app`، يخير المستخدم بين فتح **الواجهة الرسومية (GUI)** أو **الطرفية (CLI)**، كما يمكن استخدام الأعلام المباشرة:
    - `./app --gui` أو `./app gui`
    - `./app --cli` أو `./app cli`

---

### 2. تخصيص وتحسينات Arch Linux
* 🐧 **تكامل أصيل مع Pacman و AUR**:
  - فحص حزم Arch المعتمدة (`docker`, `python-tk`, `pipewire-pulse`, `xorg-xhost`).
  - دعم أدوات الـ AUR مثل `yay` و `paru`.
* ⚡ **دعم كامل لـ PipeWire و Wayland**:
  - استغلال صوت PipeWire الأصيل في Arch Linux بدون تشويش.
  - دعم بيئات Wayland الشائعة في Arch (مثل Hyprland, Sway, KDE Plasma 6, GNOME) مع عزل أمني فائق يمنع التجسس وضربات المفاتيح.
* 🚀 **تسريع كروت الشاشة (NVIDIA DKMS & AMD/Intel DRI)**:
  - فحص وربط `/dev/dri` و NVIDIA Container Toolkit تلقائياً.

---

### 3. استغلال الرام والمعالج بأقصى كفاءة (Turbo Hardware Acceleration)
* ⚡ **استغلال كل أنوية المعالج بالتوازي**:
  - حقن متغيرات بيئة المجمعات تلقائياً داخل الحاوية:
    `MAKEFLAGS="-j$(nproc)"` و `CARGO_BUILD_JOBS` و `NPM_CONFIG_JOBS` و `CMAKE_BUILD_PARALLEL_LEVEL`.
* ⚡ **حساب ديناميكي للذاكرة المشتركة (Dynamic SHM)**:
  - تخصيص 25% - 50% من رام النظام الحقيقي لـ `--shm-size` تلقائياً لمنع انهيار البرامج الثقيلة.
* ⚡ **وضع الرام-ديسك (RAM-Disk Build Mode)**:
  - إمكانية تشغيل التجميع داخل الرام عبر `tmpfs` لتسريع البناء حتى **50 ضعفاً**.

---

### 4. إغلاق الثغرات الأمنية (Zero-Trust Hardening)
* 🔒 منع ثغرة الـ X11 عبر تشفير وتوليد كوكيز `xauth` عشوائية مؤقتة.
* 🔒 عزل فضاء الذاكرة المشتركة (Private IPC Namespace).
* 🔒 حماية من القنابل الشوكية (`--pids-limit 4096`).
* 🔒 إسقاط الصلاحيات والامتيازات (`--cap-drop ALL` و `no-new-privileges`).
* 🔒 مطابقة الـ `UID:GID` لتفادي خروج الملفات بصلاحيات الـ root.

---

## 🚀 طريقة الاستخدام السريع على Arch Linux

### 1. تثبيت المتطلبات على Arch Linux (مرة واحدة)
```bash
sudo pacman -S --needed docker python tk pipewire-pulse xorg-xhost
sudo systemctl enable --now docker.service
sudo usermod -aG docker $USER
newgrp docker
```

### 2. إعطاء تصريح التشغيل للملف
```bash
chmod +x app
```

### 3. التشغيل واختيار الواجهة
```bash
# تشغيل البرنامج والاختيار بين GUI و CLI:
./app

# فتح الواجهة الرسومية مباشرة:
./app gui
# أو
./app --gui

# فتح واجهة الطرفية مباشرة:
./app cli
# أو
./app --cli
```

### 4. أوامر سريعة ومباشرة للمطورين:
* **تشغيل بيئة تطوير فورية للمشروع الحالي:**
  ```bash
  ./app dev
  ```
* **تفعيل وضع التيربو مع 2GB رام-ديسك:**
  ```bash
  ./app dev --ram-disk 2048
  ```
* **فحص صحة النظام ومحرك Docker:**
  ```bash
  ./app doctor
  ```
* **توليد Dockerfile احترافي للمشروع:**
  ```bash
  ./app dockerfile
  ```

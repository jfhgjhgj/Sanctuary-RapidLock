@echo off
python "%~dp0secure_sandbox_manager.py" %*

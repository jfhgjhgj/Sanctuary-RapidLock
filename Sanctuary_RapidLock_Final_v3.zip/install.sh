#!/usr/bin/env bash
# ==============================================================================
# SANCTUARY RAPIDLOCK UNIVERSAL MULTI-DISTRO INSTALLER
# Supports: Arch Linux, Ubuntu / Debian, Fedora, Rocky Linux / RHEL / CentOS
# ==============================================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m' # No Color

echo -e "${CYAN}${BOLD}"
echo "=============================================================================="
echo "         🛡️  SANCTUARY: RAPID LOCK MULTI-DISTRO INSTALLER"
echo "  Unified Zero-Trust Docker Sandbox Engine & Multi-Core Dev Accelerator"
echo "=============================================================================="
echo -e "${NC}"

# 1. Detect Operating System
DISTRO_ID="unknown"
ID_LIKE=""
PRETTY_NAME="Linux"

if [ -f /etc/os-release ]; then
    . /etc/os-release
    DISTRO_ID="${ID:-unknown}"
    ID_LIKE="${ID_LIKE:-}"
    PRETTY_NAME="${PRETTY_NAME:-Linux}"
fi

ALL_IDS="$DISTRO_ID $ID_LIKE"

echo -e "${GREEN}[+] Detected OS:${NC} ${BOLD}${PRETTY_NAME}${NC}"

# 2. Package Manager and Dependency Installation
install_arch() {
    echo -e "${CYAN}[+] Installing dependencies via Pacman...${NC}"
    sudo pacman -S --needed --noconfirm docker python tk xorg-xhost pipewire-pulse
}

install_debian() {
    echo -e "${CYAN}[+] Installing dependencies via APT...${NC}"
    sudo apt-get update
    sudo apt-get install -y docker.io python3 python3-tk x11-xserver-utils pulseaudio-utils
}

install_fedora() {
    echo -e "${CYAN}[+] Installing dependencies via DNF (Fedora)...${NC}"
    sudo dnf install -y moby-engine docker-compose python3 python3-tkinter xorg-x11-server-utils pipewire-utils
}

install_rocky() {
    echo -e "${CYAN}[+] Installing dependencies via DNF (Rocky Linux / Enterprise Linux)...${NC}"
    sudo dnf install -y epel-release || true
    if ! command -v docker &> /dev/null; then
        echo -e "${YELLOW}[!] Adding Docker CE repository...${NC}"
        sudo dnf config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo || true
        sudo dnf install -y docker-ce docker-ce-cli containerd.io python3 python3-tkinter xorg-x11-server-utils pipewire-utils
    else
        sudo dnf install -y python3 python3-tkinter xorg-x11-server-utils pipewire-utils
    fi
}

if [ -f /etc/arch-release ] || [[ "$ALL_IDS" =~ (arch|manjaro|endeavouros|artix|garuda) ]]; then
    install_arch
elif [[ "$ALL_IDS" =~ fedora ]]; then
    install_fedora
elif [[ "$ALL_IDS" =~ (rhel|centos|rocky|almalinux) ]]; then
    install_rocky
elif [[ "$ALL_IDS" =~ (debian|ubuntu|mint|pop|kali) ]]; then
    install_debian
else
    echo -e "${YELLOW}[!] Unrecognized distribution. Attempting generic install...${NC}"
    if command -v pacman &> /dev/null; then install_arch
    elif command -v apt-get &> /dev/null; then install_debian
    elif command -v dnf &> /dev/null; then install_fedora
    else
        echo -e "${RED}[X] Error: Could not determine package manager. Please install docker, python3, and python-tk manually.${NC}"
    fi
fi

# 3. Enable and Start Docker Service
echo -e "${CYAN}[+] Enabling and starting Docker daemon...${NC}"
if command -v systemctl &> /dev/null; then
    sudo systemctl enable --now docker.service || sudo systemctl enable --now docker
fi

# Add Current User to Docker Group
if getent group docker > /dev/null 2>&1; then
    echo -e "${CYAN}[+] Adding user '${USER}' to docker group...${NC}"
    sudo usermod -aG docker "$USER" || true
fi

# 4. Install Executables & Symlinks
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_BIN="/usr/local/bin"

echo -e "${CYAN}[+] Installing Sanctuary RapidLock binaries to ${TARGET_BIN}...${NC}"
sudo chmod +x "${SCRIPT_DIR}/app" "${SCRIPT_DIR}/rapidlock"
sudo cp "${SCRIPT_DIR}/app" "${TARGET_BIN}/app"
sudo cp "${SCRIPT_DIR}/rapidlock" "${TARGET_BIN}/rapidlock"
sudo ln -sf "${TARGET_BIN}/app" "${TARGET_BIN}/sanctuary-rapidlock"

# 5. Desktop Application Shortcut
DESKTOP_DIR="/usr/share/applications"
if [ -d "$DESKTOP_DIR" ]; then
    echo -e "${CYAN}[+] Installing Desktop Launcher...${NC}"
    sudo cat <<EOF | sudo tee "${DESKTOP_DIR}/sanctuary-rapidlock.desktop" > /dev/null
[Desktop Entry]
Version=1.1
Type=Application
Name=Sanctuary: Rapid Lock
GenericName=Hardened Docker Sandbox & Accelerator
Comment=Zero-Trust Hardened Docker Sandbox Engine & Multi-Core Dev Accelerator
Exec=/usr/local/bin/app
Icon=utilities-terminal
Terminal=false
Categories=Development;Utility;Security;
Keywords=docker;sandbox;security;arch;ubuntu;fedora;rocky;
EOF
fi

echo -e "${GREEN}${BOLD}"
echo "=============================================================================="
echo "  ✅ Sanctuary RapidLock installed successfully!"
echo "=============================================================================="
echo -e "${NC}"
echo "You can now run:"
echo "  - app              (Open GUI or CLI selector)"
echo "  - app gui          (Open Modern Dark GUI Dashboard)"
echo "  - app cli          (Open Interactive Terminal Panel)"
echo "  - app dev          (Launch Instant Dev Sandbox for current directory)"
echo "  - app doctor       (Run System Diagnostics)"
echo ""
echo -e "${YELLOW}Note: If you were just added to the docker group, please log out and back in, or run:${NC}"
echo "  newgrp docker"
echo ""
